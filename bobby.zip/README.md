# Bobby (Forge 1.20.1)

Bobby es un ligón con encanto: pelo con tupé, chaqueta de cuero, vaqueros, cadena de oro y una flor en la mano.
Es de tamaño jugador (1,8 bloques, más bajo que un aldeano).

## Cómo se comporta
- **Liga contigo**: si estás cerca (14 bloques) y te ve, se acerca, te mira, ladea la cabeza, lanza besos
  (corazones) y suelta frases de ligar (10 distintas) cada pocos segundos.
- **"¡Somos pareja!"**: tras unos cuantos ligues, a veces afirma que sois pareja y **te roba algo** (hasta 16
  unidades de una casilla de tu inventario; nunca la armadura). Lo lleva en la mano izquierda, bien visible.
  No roba a jugadores en creativo.
- **Si le das un golpe**, se disculpa y **te lo devuelve**, pero sigue con su actitud pícara (volverá a
  intentarlo pasado un rato). Si lo matas, suelta lo robado.
- **Te defiende**: ataca a los monstruos que te estén atacando (pega flojito: no es el más fuerte) y huye si le
  queda poca vida. Nunca ataca a jugadores.

## Aparición
- Natural: llanuras, bosques, sabanas, desiertos, junglas, taigas y otros biomas terrestres.
- De visita: de día, cerca de los jugadores (~una vez cada 8 min por jugador, si no hay otro Bobby a 100 bloques).
- Huevo generador en la pestaña creativa "Bobby", o `/summon bobby:bobby`.

## Ajustes
- `entity/BobbyEntity.java`: MAX_STEAL, FLIRTS_BEFORE_THEFT, vida, daño, velocidad.
- `event/BobbySpawner.java`: frecuencia de las visitas.
- `assets/bobby/lang/*.json`: las frases (añade o cambia las que quieras).
- `data/bobby/forge/biome_modifier/bobby_spawns.json`: biomas y peso de aparición.

## Compilar en GitHub
Sube el .zip (o su contenido) con `.github/workflows/build.yml` -> Actions -> el .jar sale en Releases/Artifacts.
