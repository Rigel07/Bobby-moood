package com.bobby.event;

import com.bobby.BobbyMod;
import com.bobby.entity.BobbyEntity;
import com.bobby.entity.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Ademas de aparecer al generar el mundo, Bobby "pasa de visita" de dia cerca de los jugadores. */
@Mod.EventBusSubscriber(modid = BobbyMod.MOD_ID)
public class BobbySpawner {
    // ======== AJUSTES ========
    private static final int CHECK_INTERVAL = 1200;   // cada minuto
    private static final double CHANCE = 0.12;        // ~ una visita cada 8 min por jugador
    // =========================

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % CHECK_INTERVAL != 0 || !level.isDay()) return;

        for (ServerPlayer p : level.players()) {
            if (p.isSpectator() || level.random.nextDouble() >= CHANCE) continue;
            if (!level.getEntitiesOfClass(BobbyEntity.class, p.getBoundingBox().inflate(100.0D)).isEmpty()) continue;

            double ang = level.random.nextDouble() * Math.PI * 2;
            double dist = 24 + level.random.nextDouble() * 16;
            int x = (int) Math.floor(p.getX() + Math.cos(ang) * dist);
            int z = (int) Math.floor(p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.getFluidState(pos.below()).isEmpty() || !level.getBlockState(pos.below()).isSolid()) continue;
            ModEntities.BOBBY.get().spawn(level, pos, MobSpawnType.EVENT);
        }
    }
}
