package com.bobby.client;

import com.bobby.entity.BobbyEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Modelo de jugador (brazos anchos) con pose de ligon: cabeza ladeada, "beso" con una mano y la otra en la cadera. */
public class BobbyModel extends PlayerModel<BobbyEntity> {

    public BobbyModel(ModelPart root) {
        super(root, false);
    }

    @Override
    public void setupAnim(BobbyEntity e, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (e.isFlirting()) {
            this.rightArm.xRot = -1.5F + Mth.sin(ageInTicks * 0.25F) * 0.1F;
            this.rightArm.yRot = -0.45F;
            this.leftArm.xRot = -0.3F;
            this.leftArm.zRot = -0.3F;
            this.head.zRot = 0.18F;
            this.head.xRot = -0.05F;
            this.hat.copyFrom(this.head);
            this.rightSleeve.copyFrom(this.rightArm);
            this.leftSleeve.copyFrom(this.leftArm);
        }
    }
}
