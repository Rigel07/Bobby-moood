package com.bobby.client;

import com.bobby.BobbyMod;
import com.bobby.entity.BobbyEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BobbyRenderer extends HumanoidMobRenderer<BobbyEntity, BobbyModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(BobbyMod.MOD_ID, "textures/entity/bobby.png");

    public BobbyRenderer(EntityRendererProvider.Context context) {
        super(context, new BobbyModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BobbyEntity entity) {
        return TEXTURE;
    }
}
