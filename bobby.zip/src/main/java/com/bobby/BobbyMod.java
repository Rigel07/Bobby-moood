package com.bobby;

import com.bobby.entity.ModEntities;
import com.bobby.item.ModCreativeTabs;
import com.bobby.item.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(BobbyMod.MOD_ID)
public class BobbyMod {
    public static final String MOD_ID = "bobby";

    public BobbyMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
