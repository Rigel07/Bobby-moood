package com.bobby.item;

import com.bobby.BobbyMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BobbyMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + BobbyMod.MOD_ID))
                    .icon(() -> new ItemStack(ModItems.BOBBY_SPAWN_EGG.get()))
                    .displayItems((params, output) -> output.accept(ModItems.BOBBY_SPAWN_EGG.get()))
                    .build());
}
