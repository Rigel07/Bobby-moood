package com.bobby.item;

import com.bobby.BobbyMod;
import com.bobby.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, BobbyMod.MOD_ID);

    public static final RegistryObject<Item> BOBBY_SPAWN_EGG = ITEMS.register("bobby_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BOBBY, 0x3E281C, 0xF0C84B, new Item.Properties()));
}
