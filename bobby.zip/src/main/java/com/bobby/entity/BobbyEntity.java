package com.bobby.entity;

import com.bobby.entity.ai.DefendTargetGoal;
import com.bobby.entity.ai.FlirtGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Bobby: un ligon con encanto. Intenta ligar contigo; de vez en cuando afirma que sois pareja y te roba
 * algo. Si le das un golpe se disculpa y te lo devuelve (pero sigue con su actitud pilla). No es el mas
 * fuerte, pero defiende al jugador de los monstruos que le atacan.
 */
public class BobbyEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> FLIRTING =
            SynchedEntityData.defineId(BobbyEntity.class, EntityDataSerializers.BOOLEAN);

    // ======== AJUSTES ========
    /** Items maximos que roba de una casilla. */
    private static final int MAX_STEAL = 16;
    /** Minimo de "ligues" antes de intentar un robo. */
    private static final int FLIRTS_BEFORE_THEFT = 3;
    // =========================

    private ItemStack stolen = ItemStack.EMPTY;
    @Nullable
    private UUID victim;
    private int flirtTicks = 0;
    private int flirtCount = 0;
    private int theftCooldown = 400;
    private int hitLineCooldown = 0;
    private int defendLineCooldown = 0;

    public BobbyEntity(EntityType<? extends BobbyEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)   // no es el mas fuerte
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    public static boolean checkBobbySpawnRules(EntityType<BobbyEntity> type, LevelAccessor level,
                                               MobSpawnType reason, BlockPos pos, RandomSource random) {
        BlockState below = level.getBlockState(pos.below());
        boolean ground = below.is(BlockTags.ANIMALS_SPAWNABLE_ON) || below.is(BlockTags.SAND) || below.is(BlockTags.DIRT);
        return ground && level.getRawBrightness(pos, 0) > 8;
    }

    // ------------------------------------------------------------ IA
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D) {
            @Override
            public boolean canUse() { return getHealth() < 6.0F && super.canUse(); }
        });
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(3, new FlirtGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        // defiende al jugador de los monstruos que le atacan, y se enfrenta a quien le golpee (monstruos)
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this) {
            @Override
            public boolean canUse() { return getLastHurtByMob() instanceof Monster && super.canUse(); }
        });
        this.targetSelector.addGoal(2, new DefendTargetGoal(this));
    }

    // ------------------------------------------------------------ datos
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(FLIRTING, false);
    }

    public boolean isFlirting() { return this.entityData.get(FLIRTING); }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        // siempre con una flor para ligar
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.POPPY));
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (!stolen.isEmpty()) tag.put("Stolen", stolen.save(new CompoundTag()));
        if (victim != null) tag.putUUID("Victim", victim);
        tag.putInt("TheftCooldown", theftCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Stolen")) {
            stolen = ItemStack.of(tag.getCompound("Stolen"));
            if (!stolen.isEmpty()) {
                setItemSlot(EquipmentSlot.OFFHAND, stolen.copy());
                setDropChance(EquipmentSlot.OFFHAND, 0.0F);
            }
        }
        if (tag.hasUUID("Victim")) victim = tag.getUUID("Victim");
        theftCooldown = tag.getInt("TheftCooldown");
    }

    // ------------------------------------------------------------ comportamiento
    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;
        if (flirtTicks > 0 && --flirtTicks == 0) this.entityData.set(FLIRTING, false);
        if (theftCooldown > 0) theftCooldown--;
        if (hitLineCooldown > 0) hitLineCooldown--;
        if (defendLineCooldown > 0) defendLineCooldown--;
    }

    private void say(ServerPlayer p, String key) {
        p.sendSystemMessage(Component.translatable("chat.type.text", this.getDisplayName(), Component.translatable(key)));
    }

    private void hearts(int count) {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.9, getZ(), count, 0.3, 0.3, 0.3, 0.02);
        }
    }

    /** Lo llama FlirtGoal cada pocos segundos mientras estas cerca. */
    public void flirt(ServerPlayer p) {
        flirtCount++;
        flirtTicks = 50;
        this.entityData.set(FLIRTING, true);
        hearts(5);
        if (stolen.isEmpty() && theftCooldown <= 0 && flirtCount >= FLIRTS_BEFORE_THEFT
                && !p.getAbilities().instabuild && this.random.nextInt(3) == 0 && stealFrom(p)) {
            return;
        }
        say(p, "bobby.flirt." + this.random.nextInt(10));
        this.playSound(SoundEvents.VILLAGER_YES, 1.0F, 0.75F);
    }

    /** "Somos pareja, ¿recuerdas?" -> te quita hasta 16 unidades de algo de tu inventario. */
    private boolean stealFrom(ServerPlayer p) {
        Inventory inv = p.getInventory();
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inv.items.size(); i++) {
            if (!inv.items.get(i).isEmpty()) slots.add(i);
        }
        if (slots.isEmpty()) return false;
        int slot = slots.get(this.random.nextInt(slots.size()));
        int amount = Math.min(inv.items.get(slot).getCount(), MAX_STEAL);
        ItemStack taken = inv.removeItem(slot, amount);
        if (taken.isEmpty()) return false;

        stolen = taken;
        victim = p.getUUID();
        setItemSlot(EquipmentSlot.OFFHAND, taken.copy());
        setDropChance(EquipmentSlot.OFFHAND, 0.0F);
        setPersistenceRequired();
        theftCooldown = 1200 + this.random.nextInt(1200);

        say(p, "bobby.steal." + this.random.nextInt(5));
        p.displayClientMessage(Component.translatable("bobby.hint"), true);
        this.playSound(SoundEvents.ALLAY_ITEM_TAKEN, 1.0F, 1.0F);
        hearts(8);
        return true;
    }

    private void giveBack(ServerPlayer p) {
        ItemStack back = stolen;
        stolen = ItemStack.EMPTY;
        victim = null;
        setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        if (!p.getInventory().add(back)) p.drop(back, false);
        theftCooldown = 800 + this.random.nextInt(800);
        say(p, "bobby.sorry." + this.random.nextInt(5));
        this.playSound(SoundEvents.ALLAY_ITEM_GIVEN, 1.0F, 1.0F);
        hearts(10);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && source.getEntity() instanceof ServerPlayer p) {
            if (!stolen.isEmpty() && p.getUUID().equals(victim)) {
                giveBack(p);              // ¡Ay! Perdona, toma lo tuyo...
            } else if (hitLineCooldown <= 0) {
                hitLineCooldown = 60;
                say(p, "bobby.hit." + this.random.nextInt(4));
            }
        }
        return super.hurt(source, amount);
    }

    /** Lo llama DefendTargetGoal cuando se lanza a defender al jugador. */
    public void onDefend() {
        if (defendLineCooldown > 0) return;
        Player p = this.level().getNearestPlayer(this, 20.0D);
        if (p instanceof ServerPlayer sp) {
            defendLineCooldown = 300;
            say(sp, "bobby.defend." + this.random.nextInt(3));
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        if (!stolen.isEmpty()) {
            this.spawnAtLocation(stolen);
            stolen = ItemStack.EMPTY;
        }
    }

    // ------------------------------------------------------------ sonidos
    @Nullable
    @Override
    protected SoundEvent getAmbientSound() { return null; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.PLAYER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.PLAYER_DEATH; }
}
