package com.bobby.entity.ai;

import com.bobby.entity.BobbyEntity;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;

/** Ataca a los monstruos que estan atacando a un jugador cercano. */
public class DefendTargetGoal extends NearestAttackableTargetGoal<Monster> {
    private final BobbyEntity bobby;

    public DefendTargetGoal(BobbyEntity bobby) {
        super(bobby, Monster.class, 10, true, false,
                e -> e instanceof Monster m && m.getTarget() instanceof Player);
        this.bobby = bobby;
    }

    @Override
    public void start() {
        super.start();
        bobby.onDefend();
    }
}
