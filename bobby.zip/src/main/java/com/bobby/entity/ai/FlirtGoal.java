package com.bobby.entity.ai;

import com.bobby.entity.BobbyEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;

/** Se acerca al jugador mas cercano y le suelta frases de ligar (o intenta algo mas pillo). */
public class FlirtGoal extends Goal {
    private final BobbyEntity bobby;
    @Nullable
    private ServerPlayer target;
    private int lineCooldown;

    public FlirtGoal(BobbyEntity bobby) {
        this.bobby = bobby;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (bobby.getTarget() != null) return false;
        Player p = bobby.level().getNearestPlayer(bobby, 14.0D);
        if (!(p instanceof ServerPlayer)) return false;
        ServerPlayer sp = (ServerPlayer) p;
        if (sp.isSpectator() || !sp.isAlive() || !bobby.hasLineOfSight(sp)) return false;
        this.target = sp;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && !target.isSpectator()
                && bobby.getTarget() == null && bobby.distanceToSqr(target) < 24.0D * 24.0D;
    }

    @Override
    public void start() {
        lineCooldown = 20 + bobby.getRandom().nextInt(30);
    }

    @Override
    public void tick() {
        if (target == null) return;
        bobby.getLookControl().setLookAt(target, 30.0F, 30.0F);
        double d = bobby.distanceTo(target);
        if (d > 3.0D) bobby.getNavigation().moveTo(target, 1.1D);
        else bobby.getNavigation().stop();
        if (d <= 4.5D && --lineCooldown <= 0) {
            lineCooldown = 110 + bobby.getRandom().nextInt(70);
            bobby.flirt(target);
        }
    }

    @Override
    public void stop() {
        target = null;
        bobby.getNavigation().stop();
    }
}
