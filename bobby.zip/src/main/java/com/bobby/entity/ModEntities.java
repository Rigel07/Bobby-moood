package com.bobby.entity;

import com.bobby.BobbyMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BobbyMod.MOD_ID);

    /** Tamano de jugador (1.8): mas bajo que un aldeano (1.95). */
    public static final RegistryObject<EntityType<BobbyEntity>> BOBBY =
            ENTITIES.register("bobby", () ->
                    EntityType.Builder.<BobbyEntity>of(BobbyEntity::new, MobCategory.CREATURE)
                            .sized(0.6f, 1.8f)
                            .clientTrackingRange(10)
                            .build(new ResourceLocation(BobbyMod.MOD_ID, "bobby").toString()));
}
